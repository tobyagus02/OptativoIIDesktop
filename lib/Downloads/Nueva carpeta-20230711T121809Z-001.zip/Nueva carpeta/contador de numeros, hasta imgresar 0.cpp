#include<iostream>
#include<conio.h>
using namespace std;
int main(){
	int numero, contador;
	do{
		cout<<"\n Digite un numero: \n"; cin>>numero;
		if(numero>0){
			contador++;
		}
	}while(numero!=0);
	
cout<<"\n El numero de valores ingresados mayores a cero es: \n"<<contador<<endl;
}