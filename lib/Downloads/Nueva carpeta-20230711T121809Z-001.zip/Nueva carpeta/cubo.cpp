#include<iostream>
#include<math.h>
using namespace std;
int main(){
	int opcion, cubo, elevar, numero;
	cout<<"\n ...MENU... \n",
	cout<<"\n DIGITE LA OPCION QUUE DESEA REALIZAR: \n"<<endl;
	cout<<"\n 1. Elevar un numero al cubo: \n";
	cout<<"\n 2. Verificar si el numero es par o impar \n";
	cout<<"\n 3. Salir \n";
	cin>>opcion;
	switch(opcion){
		case 1 : cout<<"\n Digite el numero que desea elevar al cubo \n"; cin>>cubo;
		elevar = pow(cubo,3);
		cout<<"\n El resultado es \n"<<elevar<<endl;
		break;
		case 2 : cout<<"\n Digite el numero que desee comparar \n"; cin>>numero;
		if(numero==0){
			cout<<"\n El numero es igual a cero: \n";
		}
		else if(numero%2==0){
			cout<<"\n El numero es par \n";
		}
		else if (numero%2==1){
		 cout<<"\n no es par: \n";
		}
		case 3 : break;
	}
}
