#include<iostream>
#include<conio.h>
using namespace std;
int main(){
	int numero;
	cout<<"\n Ingrese un numero \n"; cin>>numero;
	for(int i=2; numero>1; i++){
		while(numero%i==0){
			cout<<i<<" ";
			numero = numero/i;
		}
	}
}