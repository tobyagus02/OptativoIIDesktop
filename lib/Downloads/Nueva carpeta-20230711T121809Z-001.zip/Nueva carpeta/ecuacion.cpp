#include<iostream>
using namespace std;
int main(){
	float a,b,c,d,si;
	cout<<"\n Para realizar la siguiente ecuacion: (a+b-c)/(c-a) \n";
	cout<<"\n Ingrese valor para a \n"; cin>>a;
	cout<<"\n Ingrese valor para b \n"; cin>>b;
	cout<<"\n Ingrese valor para c \n"; cin>>c;
	cout<<"\n Ingrese valor para d \n"; cin>>d;
	si=((a+b-c)/(c-a));
	cout<<"\n El resultado es: \n"<<si<<endl;
}