#include<iostream>
using namespace std;
int main(){
	float examen1, examen2, examen3;
	int aprobadostodos, aprobadosuno, aprobadoultimo;
	cout<<"\n INGRESE LAS NOTAS DE LOS 3 EXAMENES DE 5 PERSONAS \n";
	cout<<"\n 1-100puntos \n";
	cout<<"\n OBS: 60 en adelante, aprobado \n"<<endl;
	for(int i=1; i<=5; i++){
		cout<<i<< " \n Digite la nota del primer examen: \n " ; cin>>examen1;
		cout<<i<< " \n Digite la nota del segundo examen: \n " ; cin>>examen2;
		cout<<i<< " \n Digite la nota del tercer examen: \n " ; cin>>examen3;
		cout<<"\n";
	}
	if((examen1>59.5)&&(examen2>59.5)&&(examen3>59.5)){
		aprobadostodos++;
	}
	if((examen1>59.5)||(examen2>59.5)||(examen3>59.5)){
		aprobadosuno++;
	}
	if((examen1<59.5)&&(examen2<59.5)&&(examen3>59.5)){
		aprobadoultimo++;
	}
	cout<<"\n Aprobo todos los examenes: \n"<<aprobadostodos<<endl;
	cout<<"\n Aprobo un examen: \n"<<aprobadosuno<<endl;
	cout<<"\n Aprobo el ultimo examen: \n"<<aprobadoultimo<<endl;
}
