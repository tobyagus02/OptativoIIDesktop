#include<iostream>
using namespace std;
int main(){
	int num1, num2, num3, num4;
	cout<<"\n Ingrese 4 numeros enteros \n"; cin>>num1>>num2>>num3>>num4;
	if (num1==num2==num3==num4){
		cout<<"\n Los numeros son iguales \n";
	}
	else if ((num1>num2)&&(num1>num3)&&(num1>num4)){
		cout<<"\n El primer numero ingresado es el mayor \n"<<num1<<endl;	
	}
	else if ((num2>num1)&&(num2>num3)&&(num2>num4)){
		cout<<"\n El segundo numero ingresado es el mayor \n"<<num2<<endl;	
	}
	else if ((num3>num2)&&(num3>num1)&&(num3>num4)){
		cout<<"\n El tercer numero ingresado es el mayor \n"<<num3<<endl;	
	}
	else if ((num4>num2)&&(num4>num3)&&(num4>num1)){
		cout<<"\n El cuarto numero ingresado es el mayor \n"<<num4<<endl;	
	}
}