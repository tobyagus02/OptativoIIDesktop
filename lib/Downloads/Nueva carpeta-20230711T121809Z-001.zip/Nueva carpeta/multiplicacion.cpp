#include<iostream>
#include<stdlib.h>
using namespace std;
int main(){
	int num;
	do{
		cout<<"\n Digite un numero de entre 1 al 10 que desee multiplicar: \n"; cin>>num;
	} while((num<1)||(num>10));
	for(int i=1; i<=30; i++){
		cout<<num<<"X"<<i<<"="<<num*i<<endl;
	}
	cout<<"\n\n";
	system("pause");
}