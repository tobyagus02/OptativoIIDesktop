#include<iostream>
using namespace std;
int main(){
	float practica, teoria, asistencia, promedio;
	cout<<"\n OBS: La nota practica es de 30%, la teorica 60% y la asistencia 10% \n"<<endl;
	cout<<"\n OBS2: 0-60puntos:1 61-70puntos:2 71-80puntos:3 81-90puntos:4 91-100puntos:5 \n"<<endl;
	cout<<"\n Digite nota practica de 0 a 100: \n"; cin>>practica;
	cout<<"\n Digite nota teorica de 0 a 100: \n"; cin>>teoria;
	cout<<"\n Digite nota asistencia de 0 a 100: \n"; cin>>asistencia;
	
	promedio=(practica*0.3 + teoria*0.6 + asistencia*0.1);
	cout<<"\n La nota final es: \n"<<promedio<<"puntos"<<endl;
}