#include<iostream>
#include<stdlib.h>
#include<time.h>
using namespace std;
int main(){
	int numero, contador, dato;
	srand(time(NULL));
	dato=1+rand()%(100);
	do{
		cout<<"\n Digite un numero: "; cin>>numero;
	if (numero>dato){
		cout<<"\n Digite un numero menor \n";
	}
	if (numero<dato){
		cout<<"\n Digite un numero mayor \n";
	}
	contador++;	
}while(numero!=dato);
cout<<"\n FELICIDADES ENCONTRASTE EL NUMERO!!! \n"<<dato<<endl;
cout<<"\n El numero de intentos es de: \n"<<contador<<endl;
}