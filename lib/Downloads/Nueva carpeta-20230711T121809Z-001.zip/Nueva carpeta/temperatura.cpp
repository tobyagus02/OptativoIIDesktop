//cada 4 horas, durasnte 24//
#include<iostream>
#include<conio.h>
using namespace std;
int main(){
	float temperatura, mayor, menor=99;
	float sumatotal=0, promedio=0;
	for(int i=0; i<24; i=i+4){
		cout<<"\n Digite la temperatura de la hora \n"<<i<<":";
		cin>>temperatura;
		sumatotal=sumatotal+temperatura;
		if(temperatura>mayor){
			mayor=temperatura;
		}
		if(temperatura<menor){
			menor=temperatura;
		}
	}
	promedio=sumatotal/6;
	cout<<"\n La temperatura mayor es: \n"<<mayor<<endl;
	cout<<"\n La temperatura menor es: \n"<<menor<<endl;
	cout<<"\n El promedio de la temperatura es: \n"<<promedio<<endl;
	getch();
}