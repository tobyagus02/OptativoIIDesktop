#include<iostream>
#include<stdlib.h>
using namespace std;
int main(){
	int i;
	i=1;
	do{
		cout<<i<<endl;
		i++;
	}while(i<=20);
	system("pause");
}